from django.contrib import admin

from recipe.models import Recipe

admin.site.register(Recipe)
